import Header from "../components/header"; // Menggunakan header.jsx yang sudah ada

export default function VisitorLayout({ children }) {
  return (
    <div className="visitor-container">
      {/* Poin 1: Navigation Bar */}
      <Header /> 
      
      <main>{children}</main>
      
      {/* Poin 6: Footer */}
      <footer className="p-8 bg-gray-900 text-white">
        <div>Kontak: support@foodies.com | 08123456789</div>
        <div>Sosmed: @foodies_id</div>
      </footer>
    </div>
  );
}