import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <nav className="flex items-center justify-between px-10 md:px-20 py-5 bg-white/90 backdrop-blur-sm sticky top-0 z-[100] border-b border-gray-100">
      
      {/* 1. LOGO FOODIES (Poin 1) */}
      <div className="flex items-center gap-2">
        <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center shadow-orange-200 shadow-lg">
          <span className="text-white font-bold text-xl">F</span>
        </div>
        <span className="text-2xl font-bold text-slate-800 tracking-tight">
          Foodies<span className="text-orange-500">.</span>
        </span>
      </div>

      {/* 2. MENU NAVIGASI (Poin 1) - Style Growio (Kecil, Abu-abu, Hover Orange) */}
      <div className="hidden lg:flex items-center gap-10">
        <a href="#home" className="text-[15px] font-semibold text-slate-600 hover:text-orange-500 transition-colors">
          Home
        </a>
        <a href="#menu" className="text-[15px] font-semibold text-slate-600 hover:text-orange-500 transition-colors">
          Menu
        </a>
        <a href="#promo" className="text-[15px] font-semibold text-slate-600 hover:text-orange-500 transition-colors">
          Promo
        </a>
        <a href="#about" className="text-[15px] font-semibold text-slate-600 hover:text-orange-500 transition-colors">
          Tentang
        </a>
        <a href="#contact" className="text-[15px] font-semibold text-slate-600 hover:text-orange-500 transition-colors">
          Kontak
        </a>
      </div>

      {/* 3. TOMBOL AUTH (Poin 1) - Sesuai Tombol "Try For Free" Growio */}
      <div className="flex items-center gap-4">
        <Link 
          to="/auth/login" 
          className="text-[15px] font-bold text-slate-800 hover:text-orange-500 transition-all"
        >
          Sign In
        </Link>
        <Link 
          to="/auth/register" 
          className="px-7 py-3 bg-[#0B0B1F] text-white text-[15px] font-bold rounded-lg hover:bg-orange-500 shadow-xl shadow-gray-200 transition-all transform hover:-translate-y-1"
        >
          Sign Up
        </Link>
      </div>
    </nav>
  );
};

export default Header;