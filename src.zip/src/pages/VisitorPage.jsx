import VisitorLayout from "../layouts/VisitorLayout";

export default function VisitorPage() {
  // Data dummy untuk Poin 4 & 5
  const products = [...]; 
  const reviews = [...];

  return (
    <VisitorLayout>
      {/* Poin 2: Hero Section */}
      <section className="hero">...</section>

      {/* Poin 3: Tentang Foodies */}
      <section className="about">...</section>

      {/* Poin 4: Menu Favorit (Grid Cards) */}
      <div className="grid grid-cols-3">
        {products.map(p => <Card key={p.id} data={p} />)}
      </div>

      {/* Poin 5: Review Pelanggan */}
      <div className="reviews">
        {reviews.map((r, i) => (
           <img src={`https://i.pravatar.cc/150?u=${i}`} alt="avatar" />
        ))}
      </div>
    </VisitorLayout>
  );
}